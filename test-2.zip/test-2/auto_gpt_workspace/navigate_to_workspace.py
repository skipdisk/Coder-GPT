import os

def navigate_to_workspace():
    os.chdir('C:/Users/ttnguyen/Documents/test-branch')