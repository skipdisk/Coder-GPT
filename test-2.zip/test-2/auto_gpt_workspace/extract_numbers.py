import re

with open('sample.txt', 'r') as file:
  contents = file.read()
  numbers = re.findall('d+', contents)
  print(numbers)