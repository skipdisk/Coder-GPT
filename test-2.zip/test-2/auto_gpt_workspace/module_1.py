# import module_name
# write code to create first component or module of the system