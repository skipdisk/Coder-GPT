import os
print(os.listdir('.'))