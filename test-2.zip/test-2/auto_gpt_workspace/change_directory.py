import os
import logging

def change_directory(directory_name):
	try:
		os.chdir(directory_name)
		logging.info('Changed directory to: ' + os.getcwd())
	except OSError:
		logging.error('Failed to change directory.')

if __name__ == '__main__':
	root = logging.getLogger()
	root.setLevel(logging.DEBUG)

	# Add the log message handler to the logger
	handler = logging.FileHandler('auto_gpt_workspace.log')
	formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
	handler.setFormatter(formatter)
	root.addHandler(handler)

	# Modify your code to include variable for the directory path
	change_directory(os.getenv('MY_DIRECTORY_ENV_VARIABLE', default='auto_gpt_workspace')) # call function
