def get_primes(start, end):
    primes = []

    sieve = [True] * (end + 1)
    p = 2
    while p * p <= end:
        if sieve[p]:
            for i in range(p * 2, end + 1, p):
                sieve[i] = False
        p += 1

    for p in range(max(start,2), end + 1):
        if sieve[p]:
            primes.append(p)

    return primes